// SPDX-License-Identifier: GPL-3.0-or-later
#include "transceiver_sx1262.h"

#include "esphome/core/log.h"
#include "esphome/core/hal.h"

namespace esphome {
namespace wmbus_radio {

static const char *TAG = "SX1262";

// ---------------------------------------------------------------------------
// SX126x SPI command opcodes (subset used for WMBus RX)
// Reference: SX1261/2 datasheet Rev 2.2, Table 11-1
// ---------------------------------------------------------------------------
static constexpr uint8_t CMD_SET_STANDBY = 0x80;
static constexpr uint8_t CMD_SET_PACKET_TYPE = 0x8A;
static constexpr uint8_t CMD_SET_RF_FREQUENCY = 0x86;
static constexpr uint8_t CMD_SET_BUFFER_BASE_ADDRESS = 0x8F;
static constexpr uint8_t CMD_SET_MODULATION_PARAMS = 0x8B;
static constexpr uint8_t CMD_SET_PACKET_PARAMS = 0x8C;
static constexpr uint8_t CMD_SET_DIO_IRQ_PARAMS = 0x08;
static constexpr uint8_t CMD_SET_RX = 0x82;
static constexpr uint8_t CMD_GET_IRQ_STATUS = 0x12;
static constexpr uint8_t CMD_CLEAR_IRQ_STATUS = 0x02;
static constexpr uint8_t CMD_GET_RX_BUFFER_STATUS = 0x13;
static constexpr uint8_t CMD_READ_BUFFER = 0x1E;
static constexpr uint8_t CMD_GET_PACKET_STATUS = 0x14;
static constexpr uint8_t CMD_GET_RSSI_INST = 0x15;
static constexpr uint8_t CMD_GET_DEVICE_ERRORS = 0x17;
static constexpr uint8_t CMD_CLEAR_DEVICE_ERRORS = 0x07;
static constexpr uint8_t CMD_SET_DIO2_AS_RF_SWITCH_CTRL = 0x9D;
static constexpr uint8_t CMD_SET_DIO3_AS_TCXO_CTRL = 0x97;
static constexpr uint8_t CMD_CALIBRATE = 0x89;
static constexpr uint8_t CMD_CALIBRATE_IMAGE = 0x98;
static constexpr uint8_t CMD_WRITE_REGISTER = 0x0D;
static constexpr uint8_t CMD_READ_REGISTER = 0x1D;

// ---------------------------------------------------------------------------
// SX126x standby / packet type constants
// STANDBY_RC   - internal RC oscillator, used after reset and before XOSC is ready
// STANDBY_XOSC - crystal oscillator, required before entering RX/TX
// ---------------------------------------------------------------------------
static constexpr uint8_t STANDBY_RC = 0x00;
static constexpr uint8_t STANDBY_XOSC = 0x01;

static constexpr uint8_t PACKET_TYPE_GFSK = 0x00;

// ---------------------------------------------------------------------------
// GFSK modulation / packet parameter constants
// ---------------------------------------------------------------------------
static constexpr uint8_t GFSK_PULSE_SHAPE_BT_0_5 = 0x09;
static constexpr uint8_t GFSK_RX_BW_312_0 = 0x19;
static constexpr uint8_t GFSK_RX_BW_234_3 = 0x0A;  // 234.3 kHz RX bandwidth
static constexpr uint8_t GFSK_PREAMBLE_DETECT_8 = 0x04;
static constexpr uint8_t GFSK_PREAMBLE_DETECT_16 = 0x05;
static constexpr uint8_t GFSK_ADDRESS_FILT_OFF = 0x00;

// SX126x GFSK header type:
// 0x00 = FIX_LEN (no length byte in-air)
// 0x01 = VAR_LEN (first payload byte is length in-air)
// WMBus does NOT carry a "GFSK length byte" at the start of the payload, so we must use FIX_LEN.
static constexpr uint8_t GFSK_PACKET_FIX_LEN = 0x00;
static constexpr uint8_t GFSK_PACKET_VAR_LEN = 0x01;

static constexpr uint8_t GFSK_CRC_OFF = 0x01;
static constexpr uint8_t GFSK_WHITENING_OFF = 0x00;

// DIO3 TCXO voltage
static constexpr uint8_t DIO3_OUTPUT_3_0 = 0x06;

// ---------------------------------------------------------------------------
// IRQ flag bits (GetIrqStatus register)
// ---------------------------------------------------------------------------
static constexpr uint16_t IRQ_RX_DONE = 0x0002;
// IRQ_SYNC_WORD_VALID: sync word matched - used as long-packet start trigger
static constexpr uint16_t IRQ_SYNC_WORD_VALID = 0x0008;

static uint16_t u16be_(const uint8_t *p) { return (uint16_t(p[0]) << 8) | uint16_t(p[1]); }
static constexpr uint16_t IRQ_TIMEOUT = 0x0200;   // RxTxTimeout
static constexpr uint16_t IRQ_CRC_ERROR = 0x0040; // CRC error

// ---------------------------------------------------------------------------
// Register addresses (SX1261/2 datasheet Rev 2.2)
// ---------------------------------------------------------------------------
// Sync word base register
static constexpr uint16_t REG_SYNC_WORD_0 = 0x06C0;

// Rx gain register (datasheet SX1261/2 Rev 2.2)
static constexpr uint16_t REG_RX_GAIN = 0x08AC;
static constexpr uint8_t RX_GAIN_POWER_SAVING = 0x94;
static constexpr uint8_t RX_GAIN_BOOSTED = 0x96;

// Semtech AN1200.53 long-packet reception registers:
//   REG_RX_ADDR_PTR      - current HW write pointer into the 256-byte circular buffer
//   REG_RXTX_PAYLOAD_LEN - intended end index; radio asserts RX_DONE when pointer reaches this value
static constexpr uint16_t REG_RX_ADDR_PTR = 0x0803;
static constexpr uint16_t REG_RXTX_PAYLOAD_LEN = 0x06BB;

// RF frequency step for SX126x: 32e6 / 2^25 (Hz)
static constexpr uint32_t XTAL_FREQ = 32000000UL;

static inline void u16_to_be(uint16_t v, uint8_t &msb, uint8_t &lsb) {
  msb = (uint8_t)((v >> 8) & 0xFF);
  lsb = (uint8_t)(v & 0xFF);
}

// ---------------------------------------------------------------------------
// wait_while_busy_: poll BUSY pin until low (command accepted).
// Bail out after 200 ms to avoid hanging on a broken SPI bus.
// ---------------------------------------------------------------------------
void SX1262::wait_while_busy_() {
  if (this->busy_pin_ == nullptr)
    return;
  const uint32_t start = millis();
  while (this->busy_pin_->digital_read()) {
    if ((millis() - start) > 200) {
      ESP_LOGW(TAG, "BUSY stuck high / linia BUSY utknela w stanie wysokim (>200ms)");
      break;
    }
    delay(1);
  }
}

// ---------------------------------------------------------------------------
// cmd_write_: send command opcode + argument bytes. BUSY checked before and after.
// ---------------------------------------------------------------------------
void SX1262::cmd_write_(uint8_t cmd, std::initializer_list<uint8_t> args) {
  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(cmd);
  for (auto b : args)
    this->delegate_->transfer(b);
  this->delegate_->end_transaction();
  this->wait_while_busy_();
}

// ---------------------------------------------------------------------------
// cmd_read_: send command + args, discard mandatory status byte, read out_len bytes.
// ---------------------------------------------------------------------------
void SX1262::cmd_read_(uint8_t cmd, std::initializer_list<uint8_t> args, uint8_t *out, size_t out_len) {
  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(cmd);
  for (auto b : args)
    this->delegate_->transfer(b);
  (void) this->delegate_->transfer(0x00);  // status
  for (size_t i = 0; i < out_len; i++)
    out[i] = this->delegate_->transfer(0x00);
  this->delegate_->end_transaction();
  this->wait_while_busy_();
}

// ---------------------------------------------------------------------------
// write_register_: write bytes to a 16-bit register address via WriteRegister command.
// ---------------------------------------------------------------------------
void SX1262::write_register_(uint16_t addr, std::initializer_list<uint8_t> data) {
  uint8_t msb, lsb;
  u16_to_be(addr, msb, lsb);

  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(CMD_WRITE_REGISTER);
  this->delegate_->transfer(msb);
  this->delegate_->transfer(lsb);
  for (auto b : data)
    this->delegate_->transfer(b);
  this->delegate_->end_transaction();
  this->wait_while_busy_();
}


// ---------------------------------------------------------------------------
// read_register8_: read one byte from a 16-bit register.
// Protocol requires one dummy byte after the address before data clocks out.
// ---------------------------------------------------------------------------
uint8_t SX1262::read_register8_(uint16_t addr) {
  uint8_t msb, lsb;
  u16_to_be(addr, msb, lsb);

  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(CMD_READ_REGISTER);
  this->delegate_->transfer(msb);
  this->delegate_->transfer(lsb);
  this->delegate_->transfer(0x00);  // dummy
  uint8_t v = this->delegate_->transfer(0x00);
  this->delegate_->end_transaction();
  this->wait_while_busy_();
  return v;
}



// ---------------------------------------------------------------------------
// get_irq_status_: read 16-bit IRQ status register, return raw flag word.
// ---------------------------------------------------------------------------
uint16_t SX1262::get_irq_status_() {
  uint8_t st[2]{};
  this->cmd_read_(CMD_GET_IRQ_STATUS, {}, st, sizeof(st));
  return (uint16_t(st[0]) << 8) | uint16_t(st[1]);
}


// ---------------------------------------------------------------------------
// read_buffer_: read out_len bytes from the 256-byte circular HW buffer.
// ReadBuffer handles wrap-around automatically, so a single call is always safe.
// ---------------------------------------------------------------------------
void SX1262::read_buffer_(uint8_t offset, uint8_t *out, size_t out_len) {
  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(CMD_READ_BUFFER);
  this->delegate_->transfer(offset);
  (void) this->delegate_->transfer(0x00);  // status
  for (size_t i = 0; i < out_len; i++)
    out[i] = this->delegate_->transfer(0x00);
  this->delegate_->end_transaction();
  this->wait_while_busy_();
}

int8_t SX1262::read_rssi_inst_dbm_() {
  // Semtech: rssi_dbm = -(rssi_raw >> 1)
  uint8_t rssi_raw = 0;
  this->cmd_read_(CMD_GET_RSSI_INST, {}, &rssi_raw, 1);
  return (int8_t)(-((int) rssi_raw) >> 1);
}


// ---------------------------------------------------------------------------
// set_rf_frequency_: convert Hz to 25-bit PLL word and program it.
// Formula: rfFreq = (freq_hz * 2^25) / XTAL_FREQ
// ---------------------------------------------------------------------------
void SX1262::set_rf_frequency_(uint32_t freq_hz) {
  uint64_t rf = ((uint64_t) freq_hz << 25) / XTAL_FREQ;
  cmd_write_(CMD_SET_RF_FREQUENCY,
             {(uint8_t) ((rf >> 24) & 0xFF), (uint8_t) ((rf >> 16) & 0xFF), (uint8_t) ((rf >> 8) & 0xFF),
              (uint8_t) (rf & 0xFF)});
}

// ---------------------------------------------------------------------------
// set_sync_word_: program the 16-bit WMBus sync word into the register bank.
//   Byte 0 = 0x54 (WMBus constant), sync2 selects format:
//     0x3D = C-mode Format B (most common), 0xCD = C-mode Format A.
// ---------------------------------------------------------------------------
void SX1262::set_sync_word_(uint8_t sync2) {
  this->write_register_(REG_SYNC_WORD_0, {0x54, sync2, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00});
}

void SX1262::set_s1_sync_word_() {
  // S-mode sync is 18 bits (0x7696) preceded here by 3 x "01" preamble bits,
  // commonly programmed as 0x54 0x76 0x96 in packet radios.
  this->write_register_(REG_SYNC_WORD_0, {0x54, 0x76, 0x96, 0x00, 0x00, 0x00, 0x00, 0x00});
}

bool SX1262::has_rx_done_() {
  uint8_t irq[2]{};
  this->cmd_read_(CMD_GET_IRQ_STATUS, {}, irq, sizeof(irq));
  const uint16_t flags = ((uint16_t) irq[0] << 8) | irq[1];
  return (flags & IRQ_RX_DONE) != 0;
}

// ---------------------------------------------------------------------------
// load_rx_buffer_: normal (non-long-packet) receive path.
// After RX_DONE, reads payload length + start pointer, loads rx_buffer_, caches RSSI.
// ---------------------------------------------------------------------------
bool SX1262::load_rx_buffer_() {
  if (!this->has_rx_done_())
    return false;

  uint8_t st[2]{};
  this->cmd_read_(CMD_GET_RX_BUFFER_STATUS, {}, st, sizeof(st));
  const uint8_t payload_len = st[0];
  const uint8_t start_ptr = st[1];

  if (payload_len == 0) {
    this->cmd_write_(CMD_CLEAR_IRQ_STATUS, {0xFF, 0xFF});
    return false;
  }

  this->rx_buffer_.assign(payload_len, 0);

  this->wait_while_busy_();
  this->delegate_->begin_transaction();
  this->delegate_->transfer(CMD_READ_BUFFER);
  this->delegate_->transfer(start_ptr);
  (void) this->delegate_->transfer(0x00);
  for (size_t i = 0; i < this->rx_buffer_.size(); i++)
    this->rx_buffer_[i] = this->delegate_->transfer(0x00);
  this->delegate_->end_transaction();
  this->wait_while_busy_();

  // Cache RSSI while the packet context is still valid.
  {
    uint8_t ps[3]{};
    this->cmd_read_(CMD_GET_PACKET_STATUS, {}, ps, sizeof(ps));
    // For GFSK: ps[2] is RSSI_avg (raw). In some corner cases (packet context lost)
    // GET_PACKET_STATUS may return zeros. Fall back to GET_RSSI_INST then.
    const int8_t rssi_avg = (int8_t)(-((int) ps[2]) >> 1);
    if (rssi_avg == 0) {
      this->last_rssi_dbm_ = this->read_rssi_inst_dbm_();
    } else {
      this->last_rssi_dbm_ = rssi_avg;
    }
  }

  this->cmd_write_(CMD_CLEAR_IRQ_STATUS, {0xFF, 0xFF});

  this->rx_idx_ = 0;
  this->rx_len_ = this->rx_buffer_.size();
  this->rx_loaded_ = true;
  return true;
}


// ---------------------------------------------------------------------------
// capture_rx_stream_: long-packet receive path, implements Semtech AN1200.53.
//
// The SX126x has a 256-byte circular HW buffer. In normal mode the radio stops
// at REG_RXTX_PAYLOAD_LEN, limiting a burst to 255 bytes. WMBus T1 with 3-of-6
// encoding can exceed this limit.
//
// AN1200.53 trick:
//   1. Set REG_RXTX_PAYLOAD_LEN = 0xFF so the radio never auto-stops.
//   2. Poll REG_RX_ADDR_PTR to see how many new bytes arrived.
//   3. Drain those bytes into rx_buffer_.
//   4. Write (current_ptr - 1) back to REG_RXTX_PAYLOAD_LEN to keep the radio alive.
//   5. Repeat until IRQ_RX_DONE / IRQ_TIMEOUT fires and data flow stops.
//
// avail = (uint8_t)(cur - state_index): intentional uint8_t wrap handles
// the 0xFF->0x00 circular pointer rollover (e.g. cur=0x0A, state=0xFA -> avail=16).
//
// The manual first/second read split below is a conservative defensive measure;
// ReadBuffer wraps automatically in HW so both produce identical results.
// ---------------------------------------------------------------------------
bool SX1262::capture_rx_stream_() {
  // Semtech AN1200.53: stream from the 256-byte internal buffer while RX is still running.
  // We rely on IRQ_RX_DONE / IRQ_TIMEOUT to decide when the burst is complete (not a tiny "silence" window),
  // otherwise we may cut valid frames (WMBus T1 airtime is several ms).
  this->rx_buffer_.clear();
  this->rx_buffer_.reserve(512);

  // Ensure payload length starts at 255 (0xFF) so the packet engine doesn't stop early.
  this->write_register_(REG_RXTX_PAYLOAD_LEN, {0xFF});

  const uint32_t start_ms = millis();
  uint32_t last_change_ms = start_ms;

  size_t copied = 0;
  uint8_t state_index = 0;  // last read index (wraps 0..255)

  // Capture until RX_DONE/TIMEOUT (latched IRQ), then allow a short drain window.
  bool seen_end_irq = false;

  while (true) {
    const uint32_t now = millis();

    // Safety: don't hang forever
    if ((now - start_ms) > 250) {
      ESP_LOGD(TAG, "Long RX capture timeout, copied=%u", (unsigned) copied);
      break;
    }
    // Hard cap (covers max WMBus T1 raw size comfortably)
    if (copied >= 512) {
      ESP_LOGD(TAG, "Long RX capture capped at 512 bytes");
      break;
    }

    const uint8_t cur = this->read_register8_(REG_RX_ADDR_PTR);
    uint8_t avail = (uint8_t) (cur - state_index);  // uint8 wrap by design

    // Cap to remaining space
    const size_t room = 512 - copied;
    if (avail > room) {
      avail = (uint8_t) room;
    }

    // Compute a "virtual" current_index (may be < cur if capped)
    const uint8_t current_index = (uint8_t) (state_index + avail);

    // Keep receiver alive: keep RxTxPldLen always behind the current write pointer.
    this->write_register_(REG_RXTX_PAYLOAD_LEN, {(uint8_t) (current_index - 1)});

    if (avail != 0) {
      uint8_t tmp[256];
      const uint8_t off = state_index;
      const uint8_t first = (uint8_t) ((off + avail <= 256) ? avail : (256 - off));
      this->read_buffer_(off, tmp, first);
      if (avail > first) {
        this->read_buffer_(0, tmp + first, (size_t) (avail - first));
      }
      this->rx_buffer_.insert(this->rx_buffer_.end(), tmp, tmp + avail);
      copied += avail;
      state_index = current_index;
      last_change_ms = now;
    } else {
      // No new bytes right now.
      const uint16_t irq = this->get_irq_status_();
      if (irq & (IRQ_RX_DONE | IRQ_TIMEOUT)) {
        seen_end_irq = true;
      }

      // After we saw end IRQ, wait a short "drain" window to pull remaining bytes, then stop.
      if (seen_end_irq && (now - last_change_ms) > 15) {
        break;
      }

      delay(1);
    }
  }

  // Cache RSSI BEFORE stopping RX (standby), otherwise GetPacketStatus may return zeros.
  // Prefer packet RSSI_avg when available; fall back to instantaneous RSSI.
  {
    uint8_t ps[3]{};
    this->cmd_read_(CMD_GET_PACKET_STATUS, {}, ps, sizeof(ps));
    const int8_t rssi_avg = (int8_t)(-((int) ps[2]) >> 1);
    if (rssi_avg == 0) {
      this->last_rssi_dbm_ = this->read_rssi_inst_dbm_();
    } else {
      this->last_rssi_dbm_ = rssi_avg;
    }
  }

  // Stop RX and clear IRQs.
  this->cmd_write_(CMD_SET_STANDBY, {STANDBY_RC});

  // ---------------------------------------------------------------------------
  // One-shot device-error snapshot (boot diagnostics).
  //
  // This block must execute ONLY ONCE - on the first captured frame after power-on.
  // It snapshots the latched SX126x device error register before and after clearing,
  // storing both values for diagnostic reporting via MQTT.
  //
  // Runs in STANDBY_RC because ClearDeviceErrors can be silently ignored in other states.
  //
  // *** BUG FIX: clear_device_errors_on_boot_ is reset to false inside this block.
  // Without it the block would run on every frame, causing:
  //   - 7 ms blocking delay per frame
  //   - boot snapshot overwritten each frame (losing the real power-on state)
  // ---------------------------------------------------------------------------
  if (this->clear_device_errors_on_boot_) {
    uint8_t de[2]{};
    this->cmd_read_(CMD_GET_DEVICE_ERRORS, {}, de, sizeof(de));
    this->boot_dev_err_before_ = u16be_(de);

    // Ensure we're in standby before clearing.
    this->cmd_write_(CMD_SET_STANDBY, {STANDBY_RC});
    delay(5);
    this->cmd_write_(CMD_CLEAR_DEVICE_ERRORS, {0x00, 0x00});
    delay(2);
    this->cmd_read_(CMD_GET_DEVICE_ERRORS, {}, de, sizeof(de));
    this->boot_dev_err_after_ = u16be_(de);
    this->boot_dev_err_valid_ = true;
    this->clear_device_errors_on_boot_ = false;  // <<< FIX: run only once
  }
  this->cmd_write_(CMD_CLEAR_IRQ_STATUS, {0xFF, 0xFF});

  if (this->rx_buffer_.empty())
    return false;

  this->rx_idx_ = 0;
  this->rx_len_ = this->rx_buffer_.size();
  this->rx_loaded_ = true;

  ESP_LOGD(TAG, "Long RX captured %u bytes", (unsigned) this->rx_len_);
  return true;
}



// ---------------------------------------------------------------------------
// setup: called once by ESPHome at boot.
// Configures FEM pins (if defined), resets the SX1262, and programs all
// static RF / modulation / packet parameters.
// ---------------------------------------------------------------------------
void SX1262::setup() {
  this->irq_edge_ = gpio::INTERRUPT_RISING_EDGE;
  this->common_setup();
  ESP_LOGV(TAG, "Setup");
  {
    const char *lm = (this->listen_mode_ == LISTEN_MODE_T1) ? "T1 only"
                   : (this->listen_mode_ == LISTEN_MODE_C1) ? "C1 only"
                   : (this->listen_mode_ == LISTEN_MODE_S1) ? "S1 only"
                   : "T1+C1 (both, 3:1 bias)";
    ESP_LOGI(TAG, "Listen mode / tryb nasluchu: %s", lm);
  }

  // MUST be before any SPI transfers
  this->spi_setup();

  // Optional FEM pins (if used instead of YAML switch/output)
  if (this->fem_en_pin_ != nullptr) {
    this->fem_en_pin_->setup();
    this->fem_en_pin_->digital_write(true);
  }
  if (this->fem_ctrl_pin_ != nullptr) {
    this->fem_ctrl_pin_->setup();
    this->fem_ctrl_pin_->digital_write(true);
  }
  if (this->fem_pa_pin_ != nullptr) {
    this->fem_pa_pin_->setup();
    this->fem_pa_pin_->digital_write(false);
  }

  this->reset();
  delay(10);

  // Apply RX gain (datasheet values)
  const uint8_t gain =
      (this->rx_gain_ == SX1262RxGain::POWER_SAVING) ? RX_GAIN_POWER_SAVING : RX_GAIN_BOOSTED;
  this->write_register_(REG_RX_GAIN, {gain});
  ESP_LOGI(TAG, "RX gain / wzmocnienie RX: %s", (this->rx_gain_ == SX1262RxGain::POWER_SAVING) ? "POWER_SAVING" : "BOOSTED");

  this->cmd_write_(CMD_SET_STANDBY, {STANDBY_RC});

  // DIO2 RF switch
  this->cmd_write_(CMD_SET_DIO2_AS_RF_SWITCH_CTRL, {uint8_t(this->dio2_rf_switch_ ? 0x01 : 0x00)});

  // TCXO only if enabled
  if (this->has_tcxo_) {
    this->cmd_write_(CMD_SET_DIO3_AS_TCXO_CTRL, {DIO3_OUTPUT_3_0, 0x00, 0x00, 0x40});
    delay(5);
  }

  // Full block calibration first, then image calibration for 868 MHz.
  // Test profile aligned with the simpler SX1262 init used by Szczepan.
  this->cmd_write_(CMD_CALIBRATE, {0x3F});  // all blocks except image calibration
  this->cmd_write_(CMD_CALIBRATE_IMAGE, {0xD7, 0xDB});

  this->cmd_write_(CMD_SET_PACKET_TYPE, {PACKET_TYPE_GFSK});
  this->set_rf_frequency_(this->configured_frequency_hz_);

  this->cmd_write_(CMD_SET_BUFFER_BASE_ADDRESS, {0x00, 0x00});

  // Modulation params. T1/C1 use 100 kbps; S1 uses 32.768 kcps Manchester.
  const uint32_t bitrate = (this->listen_mode_ == LISTEN_MODE_S1) ? 32768UL : 100000UL;
  const uint32_t br = (XTAL_FREQ * 32UL) / bitrate;

  const uint32_t freq_dev = (this->listen_mode_ == LISTEN_MODE_C1) ? 45000UL : 50000UL;
  const uint32_t fdev = ((uint64_t) freq_dev << 25) / XTAL_FREQ;
  const uint8_t rx_bw = GFSK_RX_BW_234_3;  // test: Szczepan-like narrower RX bandwidth for T1/C1

  {
    char buf[96];
    snprintf(buf, sizeof(buf), "freq=%.3fMHz bitrate=%lukbps fdev=%lukHz BT=0.5 RxBW=%s%s",
             this->configured_frequency_hz_ / 1000000.0f,
             (unsigned long) (bitrate / 1000UL),
             (unsigned long) (freq_dev / 1000UL),
             (rx_bw == GFSK_RX_BW_234_3) ? "234kHz" : "312kHz",
             (this->listen_mode_ == LISTEN_MODE_S1) ? " Manchester/S-mode" : "");
    this->rf_params_str_ = buf;
  }

  this->cmd_write_(CMD_SET_MODULATION_PARAMS,
                   {(uint8_t) ((br >> 16) & 0xFF), (uint8_t) ((br >> 8) & 0xFF), (uint8_t) (br & 0xFF),
                    GFSK_PULSE_SHAPE_BT_0_5, rx_bw, (uint8_t) ((fdev >> 16) & 0xFF),
                    (uint8_t) ((fdev >> 8) & 0xFF), (uint8_t) (fdev & 0xFF)});

  // Packet params
  const uint16_t preamble_bits = 16;  // test: Szczepan-like shorter preamble
  const uint8_t preamble_msb = (uint8_t) ((preamble_bits >> 8) & 0xFF);
  const uint8_t preamble_lsb = (uint8_t) (preamble_bits & 0xFF);

  // Always FIX_LEN for WMBus.
  const uint8_t pkt_len_mode = GFSK_PACKET_FIX_LEN;
  this->cmd_write_(CMD_SET_PACKET_PARAMS,
                   {preamble_msb, preamble_lsb, GFSK_PREAMBLE_DETECT_8,
                    static_cast<uint8_t>((this->listen_mode_ == LISTEN_MODE_S1) ? 0x18 : 0x10),  // 24 bits sync for S1, 16 bits for T1/C1
                    GFSK_ADDRESS_FILT_OFF, pkt_len_mode,
                    0xFF,  // max payload
                    GFSK_CRC_OFF, GFSK_WHITENING_OFF});

  // IRQ routing -> DIO1
  const bool stream_on_sync = this->long_gfsk_packets_ || (this->listen_mode_ == LISTEN_MODE_S1);
  const uint16_t mask = stream_on_sync ? (IRQ_SYNC_WORD_VALID | IRQ_RX_DONE | IRQ_CRC_ERROR | IRQ_TIMEOUT)
                                       : (IRQ_RX_DONE | IRQ_CRC_ERROR | IRQ_TIMEOUT);
  const uint8_t mask_msb = (uint8_t) ((mask >> 8) & 0xFF);
  const uint8_t mask_lsb = (uint8_t) (mask & 0xFF);

  this->cmd_write_(CMD_SET_DIO_IRQ_PARAMS,
                   {mask_msb, mask_lsb,  // IRQ mask
                    mask_msb, mask_lsb,  // DIO1 mask
                    0x00, 0x00,          // DIO2 mask
                    0x00, 0x00});        // DIO3 mask

  this->restart_rx();
  ESP_LOGV(TAG, "SX1262 setup done");
}

// ---------------------------------------------------------------------------
// restart_rx: re-arm the receiver for the next WMBus frame.
//
// WMBus C-mode has two formats differing only in the second sync byte.
// We cycle 3:1 towards Format B (0x3D) as it is more common in practice,
// so both formats are caught without any user configuration.
// ---------------------------------------------------------------------------
void SX1262::restart_rx() {
  // Ping-pong between C-mode Block B (0x3D) and Block A (0xCD)
  // WMBus C-mode exists in two Format variants that differ only in the second
  // sync byte: Format A uses 0x3D, Format B uses 0xCD. Both are valid C1
  // transmissions and real devices may transmit Format A.
  // C1-only MUST cycle through both sync bytes exactly like `both` mode —
  // otherwise Format A packets are silently missed.
  // Bug: previous code hardcoded 0xCD (Format B only) in C1-only mode.
  // Fix: apply the same 3:1 (A:B) cycling used in `both` mode.
  // NOTE: do NOT revert C1-only to a fixed 0xCD; that breaks Format A.
  if (this->listen_mode_ == LISTEN_MODE_S1) {
    this->set_s1_sync_word_();
    this->cmd_write_(CMD_CLEAR_IRQ_STATUS, {0xFF, 0xFF});
    this->cmd_write_(CMD_SET_STANDBY, {STANDBY_XOSC});
    this->cmd_write_(CMD_SET_RX, {0xFF, 0xFF, 0xFF});
    this->rx_loaded_ = false;
    this->rx_idx_ = 0;
    this->rx_len_ = 0;
    return;
  }

  uint8_t sync2;
  if (this->listen_mode_ == LISTEN_MODE_T1) {
    sync2 = 0x3D;
  } else if (this->listen_mode_ == LISTEN_MODE_C1) {
    // Cycle 3:1 (A:B) — same ratio as `both` mode.
    sync2 = (this->sync_cycle_ == 3) ? 0xCD : 0x3D;
    this->sync_cycle_ = (uint8_t) ((this->sync_cycle_ + 1) & 0x03);
  } else {
    sync2 = (this->sync_cycle_ == 3) ? 0xCD : 0x3D;
    this->sync_cycle_ = (uint8_t) ((this->sync_cycle_ + 1) & 0x03);
  }

  this->set_sync_word_(sync2);

  this->cmd_write_(CMD_CLEAR_IRQ_STATUS, {0xFF, 0xFF});
  this->cmd_write_(CMD_SET_STANDBY, {STANDBY_XOSC});

  // RX continuous
  this->cmd_write_(CMD_SET_RX, {0xFF, 0xFF, 0xFF});

  this->rx_loaded_ = false;
  this->rx_idx_ = 0;
  this->rx_len_ = 0;
}


// ---------------------------------------------------------------------------
// read: called byte-by-byte by the receiver task.
// On first call after an IRQ: loads buffer (normal) or streams (long-packet).
// Subsequent calls return successive bytes from rx_buffer_ until exhausted.
// ---------------------------------------------------------------------------
optional<uint8_t> SX1262::read() {
  if (!this->rx_loaded_) {
    if (this->long_gfsk_packets_ || this->listen_mode_ == LISTEN_MODE_S1) {
      // Don't start a long capture unless an IRQ is latched (SyncWordValid / RxDone / Timeout / CRCError).
      // Otherwise we'd stop RX periodically and miss frames.
      const uint16_t irq = this->get_irq_status_();
      if ((irq & (IRQ_SYNC_WORD_VALID | IRQ_RX_DONE | IRQ_TIMEOUT | IRQ_CRC_ERROR)) == 0) {
        return {};
      }
      ESP_LOGD(TAG, "IRQ=%04X, capturing RX stream (long GFSK)", irq);
      if (!this->capture_rx_stream_())
        return {};
    } else {
      if (!this->irq_pin_->digital_read())
        return {};
      ESP_LOGD(TAG, "IRQ detected, loading buffer");
      if (!this->load_rx_buffer_())
        return {};
    }
  }

  if (this->rx_idx_ < this->rx_len_)
    return this->rx_buffer_[this->rx_idx_++];
  return {};
}

// ---------------------------------------------------------------------------
// get_rssi: return RSSI (dBm) cached at packet capture time.
// In long-GFSK mode the radio enters standby after capture, so
// GetPacketStatus would return zeros if queried here.
// ---------------------------------------------------------------------------
int8_t SX1262::get_rssi() {
  // Return cached RSSI captured when the RX buffer was filled.
  // In long-GFSK mode we stop RX after capture, so live GetPacketStatus
  // would often read as 0.
  return this->last_rssi_dbm_;
}


// ---------------------------------------------------------------------------
// log_reg_status: diagnostic hook used by the component/base transceiver.
// Keep it lightweight; this is not part of the RX hot path.
// ---------------------------------------------------------------------------
void SX1262::log_reg_status() {
  const uint8_t rx_gain = this->read_register8_(REG_RX_GAIN);
  const uint8_t rx_ptr = this->read_register8_(REG_RX_ADDR_PTR);
  const uint8_t payload_len = this->read_register8_(REG_RXTX_PAYLOAD_LEN);
  ESP_LOGI(TAG, "SX1262 regs: RX_GAIN=0x%02X RX_ADDR_PTR=0x%02X RXTX_PAYLOAD_LEN=0x%02X",
           rx_gain, rx_ptr, payload_len);
}

const char *SX1262::get_name() { return TAG; }

}  // namespace wmbus_radio
}  // namespace esphome
